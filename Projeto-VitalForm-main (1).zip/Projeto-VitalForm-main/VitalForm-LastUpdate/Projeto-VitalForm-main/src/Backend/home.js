document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('alertButton').addEventListener('click', function() {
      alert('Bem-vindo ao VitalForm! O melhor site para você melhorar a sua saúde!');
    });
  });
  

